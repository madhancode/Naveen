export const r_Fields = [
    {
        name: "Name",
        id: "uname",
        type: "text"
    },
    {
        name: "Date of Birth",
        id: "dob",
        type: "date"
    },
    {
      name: "Email",
      id: "mail",
      type: "email"
    },
    {
      name: "Password",
      id: "pass",
      type: "password"
    }
  ];
  